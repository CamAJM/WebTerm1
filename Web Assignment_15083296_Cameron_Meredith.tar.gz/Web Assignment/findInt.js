var https = require("https");
var fs = require("fs");



var options = {
	hostname: "en.wikipedia.org",
	port: 443,
	path: "/wiki/Bank_of_England",
	method: "GET"
};

var req = https.request(options, function(res) {

	var responseBody = "";

	console.log("Response from server started.");
	console.log(`Server Status: ${res.statusCode} `);
	console.log("Response Headers: %j", res.headers);

	res.setEncoding("UTF-8");

	res.once("data", function(chunk) {
		console.log(chunk);
	});

	res.on("data", function(chunk) {
	   // console.log(--chunk-- ${chunk.length});
          
	    var x = '<th scope="row">Interest rate target</th>';
		var y = '<td> '
	//    console.log(chunk);
	//    console.log("-----------------------------------------------");
	   if(chunk.match(x))
	    {
			console.log("Found match to " + x  + " in given page ");
			// Found it. Now need to print out the inner html of the following td.... But how?
			console.log()
	    }
	    
		responseBody += chunk;


	});

	res.on("end", function() {
		fs.writeFile("download.html", responseBody, function(err) {
			if (err) {
				throw err;
			}
			console.log("File Downloaded");
		});
		
		
			
		
		fs.readFile("./download.html", "utf8",function (err, data){
			if (err) 
			{
				throw err;
			}
			
			var content = data
			
			
			
			processFile(content);
			
			
			
		});
		
		
		
			
		function processFile(content)
		{
			
			var index = content.indexOf('Interest rate target')
			
			var tempString = content.substring(0, index);
			
			var lineNumber = tempString.split('\n').length
			
			console.log(lineNumber)
			 
		
			var stream = fs.createReadStream("download.html", {encoding: "utf-8", start: lineNumber, end: (lineNumber+1) });		
		
			stream.on("data", function(data) {
				
				console.log(data)
				
				
			});
			
			
			
			
			
			
			
		};
									   
	
		
		
	});

});



req.end();
